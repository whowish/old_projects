CREATE DATABASE  IF NOT EXISTS `swapsquare` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;
USE `swapsquare`;
-- MySQL dump 10.13  Distrib 5.5.16, for osx10.5 (i386)
--
-- Host: collegeswap.cwpo65w8mozx.us-east-1.rds.amazonaws.com    Database: swapsquare
-- ------------------------------------------------------
-- Server version	5.5.12-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `item_images`
--

DROP TABLE IF EXISTS `item_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `original_image_path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ordered_number` int(11) NOT NULL,
  `item_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_images`
--

LOCK TABLES `item_images` WRITE;
/*!40000 ALTER TABLE `item_images` DISABLE KEYS */;
INSERT INTO `item_images` VALUES (1,'item_1_1.jpg',0,1),(2,'item_2_2.jpg',0,2),(3,'item_7_3.jpg',0,7),(4,'item_15_4.png',0,15),(5,'item_16_5.jpg',0,16),(6,'item_28_6.jpg',0,28),(7,'item_29_7.jpg',0,29),(8,'item_32_8.jpg',0,32),(9,'item_33_9.jpg',0,33),(10,'item_34_10.jpg',0,34),(11,'item_36_11.png',0,36),(12,'item_39_12.jpg',0,39),(13,'item_40_13.jpg',0,40),(14,'item_42_14.gif',0,42),(15,'item_43_15.gif',0,43),(16,'item_45_16.jpg',0,45),(17,'item_46_17.jpg',0,46),(18,'item_47_18.jpg',0,47),(19,'item_48_19.jpg',0,48),(20,'item_49_20.png',0,49),(21,'item_51_21.jpg',0,51),(23,'item_52_23.jpg',0,52),(24,'item_54_24.jpg',0,54),(25,'item_55_25.jpg',0,55),(26,'item_56_26.jpg',0,56),(27,'item_57_27.jpg',0,57),(28,'item_90_28.jpg',0,90),(29,'item_91_29.jpg',0,91),(30,'item_105_30.jpg',0,105),(31,'item_109_31.jpg',0,109),(32,'item_110_32.jpg',0,110),(33,'item_112_33.jpg',0,112),(35,'item_111_35.jpg',0,111),(36,'item_114_36.jpg',0,114),(37,'item_115_37.jpg',0,115),(38,'item_116_38.jpg',0,116),(39,'item_117_39.jpg',0,117),(40,'item_118_40.jpg',0,118),(41,'item_119_41.jpg',0,119),(42,'item_113_42.jpg',0,113),(43,'item_120_43.jpg',0,120),(44,'item_121_44.jpg',0,121),(45,'item_122_45.jpg',0,122),(46,'item_123_46.jpg',0,123),(47,'item_124_47.jpg',0,124),(48,'item_125_48.png',0,125),(49,'item_126_49.jpg',0,126),(50,'item_127_50.jpg',0,127),(51,'item_129_51.jpg',0,129),(52,'item_130_52.jpg',0,130),(53,'item_132_53.jpg',0,132),(54,'item_134_54.jpg',0,134),(55,'item_143_55.jpg',0,143);
/*!40000 ALTER TABLE `item_images` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-03-16 16:46:30
