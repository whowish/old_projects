CREATE DATABASE  IF NOT EXISTS `swapsquare` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;
USE `swapsquare`;
-- MySQL dump 10.13  Distrib 5.5.16, for osx10.5 (i386)
--
-- Host: collegeswap.cwpo65w8mozx.us-east-1.rds.amazonaws.com    Database: swapsquare
-- ------------------------------------------------------
-- Server version	5.5.12-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `share_tickets`
--

DROP TABLE IF EXISTS `share_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `share_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unique_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `permission` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `finished_date` datetime DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ref` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `error_message` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `share_tickets`
--

LOCK TABLES `share_tickets` WRITE;
/*!40000 ALTER TABLE `share_tickets` DISABLE KEYS */;
INSERT INTO `share_tickets` VALUES (1,'HPEQVjMH2b','','2011-03-09 05:59:53','2011-03-09 06:00:01','COMPLETED','Add item1',''),(2,'6sppvrSxkF','publish_stream','2011-03-15 05:57:47','2011-03-15 05:58:28','COMPLETED','Add item4',''),(3,'VDNA8aGGzq','','2011-03-15 16:19:55','2011-03-15 16:19:59','COMPLETED','Add item5',''),(4,'vcF2QLTZ76','publish_stream','2011-03-15 18:11:42','2011-03-15 18:12:05','COMPLETED','Add item6',''),(5,'6EGJabCGJP','publish_stream','2011-03-15 18:51:07','2011-03-15 18:51:22','COMPLETED','Add item7',''),(6,'k6sH3tGqUk','publish_stream','2011-03-15 20:09:11','2011-03-15 20:09:23','COMPLETED','Add item14',''),(7,'MQzpckc8ax','publish_stream','2011-03-15 20:56:45','2011-03-15 20:56:52','COMPLETED','Add item15',''),(8,'cUq8Kb36yb','publish_stream','2011-03-15 21:06:19','2011-03-15 21:06:37','COMPLETED','Add item16',''),(9,'LsUsjJJsSG','publish_stream','2011-03-15 21:55:35','2011-03-15 21:55:48','COMPLETED','Add item18',''),(10,'fBQUYwE74w','','2011-03-15 22:12:17','2011-03-15 22:12:37','COMPLETED','Add item21',''),(11,'Bxwqz7kE6g','publish_stream','2011-03-16 02:49:06','2011-03-16 02:49:24','COMPLETED','Add item23',''),(12,'g5myghgpK4','publish_stream','2011-03-16 09:42:28','2011-03-16 09:42:53','COMPLETED','Add item24',''),(13,'8wJMjT9rjA','publish_stream','2011-03-16 13:15:22',NULL,'PENDING','Add item25',''),(14,'pRm5LUydDZ','publish_stream','2011-03-21 13:29:04','2011-03-21 13:29:13','COMPLETED','Add item26',''),(15,'VQAkNAFWjU','publish_stream','2011-03-21 14:22:17','2011-03-21 14:22:24','COMPLETED','Add item27',''),(16,'HeeykX7Rea','publish_stream','2011-03-22 02:01:20',NULL,'PENDING','Add item28',''),(17,'wYMw2AtL9j','','2011-03-22 02:02:14','2011-03-22 02:02:16','COMPLETED','Add item29',''),(18,'wJEtEXzC5v','publish_stream','2011-03-22 20:57:33',NULL,'PENDING','Add item31',''),(19,'DSqYGhr2vA','publish_stream','2011-03-26 22:47:34',NULL,'PENDING','Add item32',''),(20,'vesMuFV5qA','publish_stream','2011-03-26 22:49:12','2011-03-26 22:49:26','COMPLETED','Add item33',''),(21,'JKpr6kbLYb','publish_stream','2011-03-27 19:38:13','2011-03-27 19:38:23','COMPLETED','swap item1',''),(22,'V4qdY5QWD4','publish_stream','2011-03-27 21:48:33','2011-03-27 21:49:13','COMPLETED','Add item36',''),(23,'jbfzzb9yCy','publish_stream','2011-03-29 17:40:23','2011-03-29 17:41:51','COMPLETED','Add item37',''),(24,'jvbczMY2mw','publish_stream','2011-03-30 15:52:47',NULL,'PENDING','Add item42',''),(25,'FNTVFPdF6k','','2011-03-30 15:54:20','2011-03-30 15:54:27','COMPLETED','Add item43',''),(26,'vpPngezDmf','publish_stream','2011-03-31 23:59:49',NULL,'PENDING','Add item45',''),(27,'7LxD3sTxqX','publish_stream','2011-04-01 00:07:38','2011-04-01 00:07:56','COMPLETED','Add item46',''),(28,'kweHEVjtRL','publish_stream','2011-04-01 01:45:53','2011-04-01 01:46:29','COMPLETED','Add item48',''),(29,'uzBgTfsNsu','publish_stream','2011-04-01 08:04:19',NULL,'PENDING','swap item2',''),(30,'AU3etRycjt','','2011-04-01 09:04:46','2011-04-01 09:04:57','COMPLETED','swap item3',''),(31,'GCAVLN972f','publish_stream','2011-04-09 23:31:36',NULL,'PENDING','Edit item59',''),(32,'cvdFA5meFy','','2011-04-14 04:04:31','2011-04-14 04:04:37','COMPLETED','Add item90',''),(33,'67fTQNSLWD','publish_stream','2011-05-03 22:28:21','2011-05-03 22:28:33','COMPLETED','Add item92',''),(34,'ZN5sBSX7CG','publish_stream','2011-05-04 19:58:54','2011-05-04 19:59:12','COMPLETED','Add item93',''),(35,'6pRAvv3Gjh','','2011-05-06 02:41:53','2011-05-06 02:42:03','COMPLETED','Add item95',''),(36,'9xvhJfb4Hd','publish_stream','2011-05-06 02:49:02','2011-05-06 02:49:09','ERROR','Add item99','(#200) The user hasn\'t authorized the application to perform this action'),(37,'HBhEw5gLGh','','2011-05-21 10:53:41','2011-05-21 10:53:49','COMPLETED','Add item105',''),(38,'9f6hF4VNLk','publish_stream','2011-06-12 08:37:05',NULL,'PENDING','Share item3',''),(39,'YrdnbBTmQ4','publish_stream','2011-06-12 08:38:50','2011-06-12 08:39:07','COMPLETED','Share item3',''),(40,'XNJ3FgXC8P','publish_stream','2011-06-27 13:52:29','2011-06-27 13:52:50','COMPLETED','Add item106',''),(41,'nNvTKZT2vB','publish_stream','2011-07-08 13:39:02','2011-07-08 13:39:22','COMPLETED','Add item107',''),(42,'cuHXdKt9Vm','publish_stream','2011-08-30 19:01:59','2011-08-30 19:02:20','COMPLETED','Add item108',''),(43,'nwQmPhXMXN','publish_stream','2011-11-29 08:04:05',NULL,'PENDING','Edit item109',''),(44,'jughuWqGrt','publish_stream','2011-11-30 05:06:19','2011-11-30 05:06:32','COMPLETED','Add item115',''),(45,'T3QbBLPyV8','publish_stream','2011-12-09 07:24:08','2011-12-09 07:24:37','COMPLETED','Add item128',''),(46,'YzA5XBzUTQ','','2011-12-23 04:37:48','2011-12-23 04:38:06','COMPLETED','Add item131',''),(47,'9FNqtVHSvT','publish_stream','2011-12-24 15:59:30','2011-12-24 15:59:39','ERROR','Edit item89','(#200) The user hasn\'t authorized the application to perform this action'),(48,'nSgXpWNd2G','publish_stream','2012-02-21 01:33:44','2012-02-21 01:34:05','COMPLETED','Add item132',''),(49,'yCaA6ZWFCc','publish_stream','2012-02-21 14:15:49','2012-02-21 14:16:06','COMPLETED','Add item133',''),(50,'rPQHFQx3KL','publish_stream','2012-02-22 07:55:42','2012-02-22 07:56:03','COMPLETED','Add item134',''),(51,'NuDZgCELx9','','2012-02-22 16:59:51','2012-02-22 16:59:53','COMPLETED','Add item135',''),(52,'BXhVd7ahn9','','2012-02-25 11:58:19','2012-02-25 11:58:29','COMPLETED','Add item136',''),(53,'uA4BXpqTXm','publish_stream','2012-02-25 12:20:49',NULL,'PENDING','Add item137',''),(54,'XbDnd4rces','publish_stream','2012-02-26 15:37:47','2012-02-26 15:38:09','COMPLETED','Add item138',''),(55,'nekAx4cHvt','publish_stream','2012-03-06 18:41:31','2012-03-06 18:42:05','COMPLETED','Add item141',''),(56,'TxupWHYkMM','publish_stream','2012-03-10 14:02:01','2012-03-10 14:02:20','ERROR','Add item143','(#200) The user hasn\'t authorized the application to perform this action'),(57,'B3FrTP4AC9','publish_stream','2012-03-10 14:04:02','2012-03-10 14:04:21','COMPLETED','Add item144','');
/*!40000 ALTER TABLE `share_tickets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-03-16 16:46:20
