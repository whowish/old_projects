CREATE DATABASE  IF NOT EXISTS `swapsquare` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;
USE `swapsquare`;
-- MySQL dump 10.13  Distrib 5.5.16, for osx10.5 (i386)
--
-- Host: collegeswap.cwpo65w8mozx.us-east-1.rds.amazonaws.com    Database: swapsquare
-- ------------------------------------------------------
-- Server version	5.5.12-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=246 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` VALUES (1,'Andorra','AD'),(2,'United Arab Emirates','AE'),(3,'Afghanistan','AF'),(4,'Antigua & Barbuda','AG'),(5,'Anguilla','AI'),(6,'Albania','AL'),(7,'Armenia','AM'),(8,'Netherlands Antilles','AN'),(9,'Angola','AO'),(10,'Antarctica','AQ'),(11,'Argentina','AR'),(12,'American Samoa','AS'),(13,'Austria','AT'),(14,'Australia','AU'),(15,'Aruba','AW'),(16,'Azerbaijan','AZ'),(17,'Bosnia and Herzegovina','BA'),(18,'Barbados','BB'),(19,'Bangladesh','BD'),(20,'Belgium','BE'),(21,'Burkina Faso','BF'),(22,'Bulgaria','BG'),(23,'Bahrain','BH'),(24,'Burundi','BI'),(25,'Benin','BJ'),(26,'Bermuda','BM'),(27,'Brunei Darussalam','BN'),(28,'Bolivia','BO'),(29,'Brazil','BR'),(30,'Bahama','BS'),(31,'Bhutan','BT'),(32,'Burma (no longer exists)','BU'),(33,'Bouvet Island','BV'),(34,'Botswana','BW'),(35,'Belarus','BY'),(36,'Belize','BZ'),(37,'Canada','CA'),(38,'Cocos (Keeling) Islands','CC'),(39,'Central African Republic','CF'),(40,'Congo','CG'),(41,'Switzerland','CH'),(42,'CÃ´te D\'ivoire (Ivory Coast)','CI'),(43,'Cook Iislands','CK'),(44,'Chile','CL'),(45,'Cameroon','CM'),(46,'China','CN'),(47,'Colombia','CO'),(48,'Costa Rica','CR'),(49,'Czechoslovakia (no longer exists)','CS'),(50,'Cuba','CU'),(51,'Cape Verde','CV'),(52,'Christmas Island','CX'),(53,'Cyprus','CY'),(54,'Czech Republic','CZ'),(55,'German Democratic Republic (no longer exists)','DD'),(56,'Germany','DE'),(57,'Djibouti','DJ'),(58,'Denmark','DK'),(59,'Dominica','DM'),(60,'Dominican Republic','DO'),(61,'Algeria','DZ'),(62,'Ecuador','EC'),(63,'Estonia','EE'),(64,'Egypt','EG'),(65,'Western Sahara','EH'),(66,'Eritrea','ER'),(67,'Spain','ES'),(68,'Ethiopia','ET'),(69,'Finland','FI'),(70,'Fiji','FJ'),(71,'Falkland Islands (Malvinas)','FK'),(72,'Micronesia','FM'),(73,'Faroe Islands','FO'),(74,'France','FR'),(75,'France, Metropolitan','FX'),(76,'Gabon','GA'),(77,'United Kingdom (Great Britain)','GB'),(78,'Grenada','GD'),(79,'Georgia','GE'),(80,'French Guiana','GF'),(81,'Ghana','GH'),(82,'Gibraltar','GI'),(83,'Greenland','GL'),(84,'Gambia','GM'),(85,'Guinea','GN'),(86,'Guadeloupe','GP'),(87,'Equatorial Guinea','GQ'),(88,'Greece','GR'),(89,'South Georgia and the South Sandwich Islands','GS'),(90,'Guatemala','GT'),(91,'Guam','GU'),(92,'Guinea-Bissau','GW'),(93,'Guyana','GY'),(94,'Hong Kong','HK'),(95,'Heard & McDonald Islands','HM'),(96,'Honduras','HN'),(97,'Croatia','HR'),(98,'Haiti','HT'),(99,'Hungary','HU'),(100,'Indonesia','ID'),(101,'Ireland','IE'),(102,'Israel','IL'),(103,'India','IN'),(104,'British Indian Ocean Territory','IO'),(105,'Iraq','IQ'),(106,'Islamic Republic of Iran','IR'),(107,'Iceland','IS'),(108,'Italy','IT'),(109,'Jamaica','JM'),(110,'Jordan','JO'),(111,'Japan','JP'),(112,'Kenya','KE'),(113,'Kyrgyzstan','KG'),(114,'Cambodia','KH'),(115,'Kiribati','KI'),(116,'Comoros','KM'),(117,'St. Kitts and Nevis','KN'),(118,'Korea, Democratic People\'s Republic of','KP'),(119,'Korea, Republic of','KR'),(120,'Kuwait','KW'),(121,'Cayman Islands','KY'),(122,'Kazakhstan','KZ'),(123,'Lao People\'s Democratic Republic','LA'),(124,'Lebanon','LB'),(125,'Saint Lucia','LC'),(126,'Liechtenstein','LI'),(127,'Sri Lanka','LK'),(128,'Liberia','LR'),(129,'Lesotho','LS'),(130,'Lithuania','LT'),(131,'Luxembourg','LU'),(132,'Latvia','LV'),(133,'Libyan Arab Jamahiriya','LY'),(134,'Morocco','MA'),(135,'Monaco','MC'),(136,'Moldova, Republic of','MD'),(137,'Madagascar','MG'),(138,'Marshall Islands','MH'),(139,'Mali','ML'),(140,'Mongolia','MN'),(141,'Myanmar','MM'),(142,'Macau','MO'),(143,'Northern Mariana Islands','MP'),(144,'Martinique','MQ'),(145,'Mauritania','MR'),(146,'Monserrat','MS'),(147,'Malta','MT'),(148,'Mauritius','MU'),(149,'Maldives','MV'),(150,'Malawi','MW'),(151,'Mexico','MX'),(152,'Malaysia','MY'),(153,'Mozambique','MZ'),(154,'Namibia','NA'),(155,'New Caledonia','NC'),(156,'Niger','NE'),(157,'Norfolk Island','NF'),(158,'Nigeria','NG'),(159,'Nicaragua','NI'),(160,'Netherlands','NL'),(161,'Norway','NO'),(162,'Nepal','NP'),(163,'Nauru','NR'),(164,'Neutral Zone (no longer exists)','NT'),(165,'Niue','NU'),(166,'New Zealand','NZ'),(167,'Oman','OM'),(168,'Panama','PA'),(169,'Peru','PE'),(170,'French Polynesia','PF'),(171,'Papua New Guinea','PG'),(172,'Philippines','PH'),(173,'Pakistan','PK'),(174,'Poland','PL'),(175,'St. Pierre & Miquelon','PM'),(176,'Pitcairn','PN'),(177,'Puerto Rico','PR'),(178,'Portugal','PT'),(179,'Palau','PW'),(180,'Paraguay','PY'),(181,'Qatar','QA'),(182,'RÃ©union','RE'),(183,'Romania','RO'),(184,'Russian Federation','RU'),(185,'Rwanda','RW'),(186,'Saudi Arabia','SA'),(187,'Solomon Islands','SB'),(188,'Seychelles','SC'),(189,'Sudan','SD'),(190,'Sweden','SE'),(191,'Singapore','SG'),(192,'St. Helena','SH'),(193,'Slovenia','SI'),(194,'Svalbard & Jan Mayen Islands','SJ'),(195,'Slovakia','SK'),(196,'Sierra Leone','SL'),(197,'San Marino','SM'),(198,'Senegal','SN'),(199,'Somalia','SO'),(200,'Suriname','SR'),(201,'Sao Tome & Principe','ST'),(202,'Union of Soviet Socialist Republics (no longer exists)','SU'),(203,'El Salvador','SV'),(204,'Syrian Arab Republic','SY'),(205,'Swaziland','SZ'),(206,'Turks & Caicos Islands','TC'),(207,'Chad','TD'),(208,'French Southern Territories','TF'),(209,'Togo','TG'),(210,'Thailand','TH'),(211,'Tajikistan','TJ'),(212,'Tokelau','TK'),(213,'Turkmenistan','TM'),(214,'Tunisia','TN'),(215,'Tonga','TO'),(216,'East Timor','TP'),(217,'Turkey','TR'),(218,'Trinidad & Tobago','TT'),(219,'Tuvalu','TV'),(220,'Taiwan, Province of China','TW'),(221,'Tanzania, United Republic of','TZ'),(222,'Ukraine','UA'),(223,'Uganda','UG'),(224,'United States Minor Outlying Islands','UM'),(225,'United States of America','US'),(226,'Uruguay','UY'),(227,'Uzbekistan','UZ'),(228,'Vatican City State (Holy See)','VA'),(229,'St. Vincent & the Grenadines','VC'),(230,'Venezuela','VE'),(231,'British Virgin Islands','VG'),(232,'United States Virgin Islands','VI'),(233,'Viet Nam','VN'),(234,'Vanuatu','VU'),(235,'Wallis & Futuna Islands','WF'),(236,'Samoa','WS'),(237,'Democratic Yemen (no longer exists)','YD'),(238,'Yemen','YE'),(239,'Mayotte','YT'),(240,'Yugoslavia','YU'),(241,'South Africa','ZA'),(242,'Zambia','ZM'),(243,'Zaire','ZR'),(244,'Zimbabwe','ZW'),(245,'Unknown or unspecified country','ZZ');
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-03-16 16:47:23
